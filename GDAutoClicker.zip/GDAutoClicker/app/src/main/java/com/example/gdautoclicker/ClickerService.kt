package com.example.gdautoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Служба доступности: выполняет нажатия (dispatchGesture) и показывает
 * плавающую панель поверх игры через TYPE_ACCESSIBILITY_OVERLAY.
 */
class ClickerService : AccessibilityService() {

    companion object {
        @Volatile var instance: ClickerService? = null
        private const val START_DELAY_MS = 0L
    }

    private val handler = Handler(Looper.getMainLooper())
    private var runId = 0
    var running = false
        private set

    private var panel: View? = null
    private var statusView: TextView? = null
    private var toggleView: TextView? = null
    private var levelName = ""
    private var levelId = ""
    private var recBtn: TextView? = null
    private var recView: View? = null
    private var recording = false
    private var recStart = 0L
    private val recTaps = mutableListOf<Tap>()
    private var pattern = Pattern()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }

    override fun onDestroy() {
        stop()
        hidePanel()
        instance = null
        super.onDestroy()
    }

    // ---------- Запуск / остановка ----------

    fun start(p: Pattern, delayMs: Long = START_DELAY_MS) {
        stop()
        pattern = p
        running = true
        val id = ++runId
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val y = dm.heightPixels / 2f
        updatePanel()
        countdown(id, delayMs) {
            if (p.mode == Mode.MACRO && p.taps.isNotEmpty()) runMacro(id, p, x, y)
            else runInterval(id, p, x, y)
        }
    }

    fun stop() {
        runId++
        running = false
        handler.removeCallbacksAndMessages(null)
        updatePanel()
    }

    private fun countdown(id: Int, delayMs: Long, then: () -> Unit) {
        var left = (delayMs / 1000).toInt()
        val tick = object : Runnable {
            override fun run() {
                if (id != runId) return
                if (left <= 0) { setStatus("Идёт…"); then(); return }
                setStatus("Старт через $left")
                left--
                handler.postDelayed(this, 1000)
            }
        }
        tick.run()
    }

    private fun runInterval(id: Int, p: Pattern, x: Float, y: Float) {
        val r = object : Runnable {
            override fun run() {
                if (id != runId) return
                tap(x, y, p.holdMs)
                handler.postDelayed(this, p.intervalMs.coerceAtLeast(p.holdMs + 5))
            }
        }
        r.run()
    }

    private fun runMacro(id: Int, p: Pattern, x: Float, y: Float) {
        fun playOnce() {
            p.taps.forEach { t ->
                handler.postDelayed({ if (id == runId) tap(x, y, t.holdMs) }, t.atMs)
            }
            val end = p.taps.maxOf { it.atMs + it.holdMs } + 300
            handler.postDelayed({
                if (id != runId) return@postDelayed
                if (p.loop) playOnce() else stop()
            }, end)
        }
        playOnce()
    }

    private fun tap(x: Float, y: Float, holdMs: Long) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, holdMs.coerceIn(1, 5000))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    // ---------- Плавающая панель ----------

    fun showPanel(id: String, name: String, p: Pattern) {
        levelId = id
        levelName = name
        pattern = p
        hidePanel()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dp = resources.displayMetrics.density

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((12 * dp).toInt(), (10 * dp).toInt(), (12 * dp).toInt(), (10 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6141A2B"))
                cornerRadius = 18 * dp
                setStroke((1 * dp).toInt(), Color.parseColor("#6C5CE7"))
            }
        }
        val title = TextView(this).apply {
            text = levelName
            setTextColor(Color.WHITE)
            textSize = 13f
        }
        statusView = TextView(this).apply {
            text = "Готов"
            setTextColor(Color.parseColor("#9AA4BF"))
            textSize = 12f
        }
        toggleView = TextView(this).apply {
            text = "▶  Старт"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#6C5CE7"))
                cornerRadius = 12 * dp
            }
            setOnClickListener { if (running) stop() else start(pattern) }
        }
        recBtn = TextView(this).apply {
            text = "●  Запись"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#FF6B6B"))
            textSize = 13f
            setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
            setOnClickListener { if (recording) stopRecording() else startRecording() }
        }
        val close = TextView(this).apply {
            text = "Закрыть панель"
            setTextColor(Color.parseColor("#9AA4BF"))
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, (8 * dp).toInt(), 0, 0)
            setOnClickListener { stop(); hidePanel() }
        }
        root.addView(title)
        root.addView(statusView)
        root.addView(toggleView, LinearLayout.LayoutParams(
            (150 * dp).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = (8 * dp).toInt() })
        root.addView(recBtn)
        root.addView(close)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * dp).toInt(); y = (80 * dp).toInt()
        }

        // Перетаскивание за заголовок
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        title.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }

        wm.addView(root, lp)
        panel = root
        updatePanel()
    }

    fun hidePanel() {
        if (recording) stopRecording()
        panel?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        panel = null
    }

    // ---------- Запись макроса поверх игры ----------
    // Нажатия вне окна ловятся через ACTION_OUTSIDE: приходит только момент касания,
    // длительность удержания Android не сообщает, поэтому берётся значение «Удержание».

    private fun startRecording() {
        stop()
        recTaps.clear()
        recStart = 0L
        recording = true
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = View(this)
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) {
                val now = SystemClock.uptimeMillis()
                if (recTaps.isEmpty()) recStart = now
                recTaps += Tap(now - recStart, pattern.holdMs.coerceAtLeast(60))
            }
            false
        }
        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, lp)
        recView = v
        recBtn?.text = "■  Стоп записи"
        setStatus("Запись: нажимайте в игре")
    }

    private fun stopRecording() {
        recording = false
        recView?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        recView = null
        recBtn?.text = "●  Запись"
        // Последнее касание — это нажатие на саму кнопку «Стоп записи»
        if (recTaps.isNotEmpty()) recTaps.removeAt(recTaps.lastIndex)
        if (recTaps.isNotEmpty()) {
            pattern = pattern.copy(mode = Mode.MACRO, taps = recTaps.toList())
            PatternStore(this).put(levelId, pattern)
            setStatus("Сохранено: ${recTaps.size} нажатий")
        } else {
            setStatus("Нажатий не записано")
        }
    }

    private fun setStatus(s: String) { statusView?.text = s }

    private fun updatePanel() {
        toggleView?.text = if (running) "■  Стоп" else "▶  Старт"
        if (!running) setStatus("Готов")
    }
}
