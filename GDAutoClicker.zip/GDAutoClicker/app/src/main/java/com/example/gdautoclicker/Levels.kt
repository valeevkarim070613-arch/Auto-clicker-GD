package com.example.gdautoclicker

data class Level(val id: String, val name: String, val group: String)

/**
 * Официальные уровни Geometry Dash.
 * Список лежит в одном месте, чтобы его было легко дополнить
 * (например, новыми уровнями из обновлений или SubZero).
 */
object Levels {
    const val G_MAIN = "Основные"
    const val G_MELTDOWN = "Meltdown"
    const val G_WORLD = "World"

    val groups = listOf(G_MAIN, G_MELTDOWN, G_WORLD)

    private val main = listOf(
        "Stereo Madness", "Back On Track", "Polargeist", "Dry Out", "Base After Base",
        "Can't Let Go", "Jumper", "Time Machine", "Cycles", "xStep", "Clutterfunk",
        "Theory of Everything", "Electroman Adventures", "Clubstep", "Electrodynamix",
        "Hexagon Force", "Blast Processing", "Theory of Everything 2",
        "Geometrical Dominator", "Deadlocked", "Fingerdash", "Dash"
    )
    private val meltdown = listOf("The Seven Seas", "Viking Arena", "Airborne Robots")
    private val world = listOf(
        "Payload", "Beast Mode", "Machina", "Years", "Frontlines",
        "Space Pirates", "Striker", "Embers", "Round 1", "Monster Dance Off"
    )

    val all: List<Level> =
        main.mapIndexed { i, n -> Level("main_${i + 1}", "${i + 1}. $n", G_MAIN) } +
        meltdown.mapIndexed { i, n -> Level("melt_${i + 1}", n, G_MELTDOWN) } +
        world.mapIndexed { i, n -> Level("world_${i + 1}", n, G_WORLD) }
}
